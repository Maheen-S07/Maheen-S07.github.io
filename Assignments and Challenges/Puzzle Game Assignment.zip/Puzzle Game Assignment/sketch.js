// Puzzle Game
// Maheen Shahid
// April 8, 2025        

let NUM_ROWS = 4;
let NUM_COLS = 5;
let rectWidth, rectHeight;
let currentRow, currentCol;
let pattern = "cross";
let gridData = [
  [0,   0,   0,   0, 0],
  [0,   0,   0,   0, 0],
  [0,   255, 0,   0, 0],
  [255, 255, 255, 0, 0]];



function setup() {
  createCanvas(windowWidth, windowHeight);
  rectWidth = width/NUM_COLS;
  rectHeight = height/NUM_ROWS;
  randomStart();
}

function draw() {
  background(220);
  currentSquare();   
  drawGrid(); 
  winner();
  drawOverlay();
}



function mousePressed(){
  // cross-shaped pattern flips on a mouseclick.
  // Boundary conditions are checked within the flip function to ensure
  // in-bounds access for array
  if(keyIsDown(SHIFT)){
    flip(currentCol, currentRow);
  }
  else{
  if(pattern === "cross"){
    flip(currentCol, currentRow);
    flip(currentCol-1, currentRow);
    flip(currentCol+1, currentRow);
    flip(currentCol, currentRow-1);
    flip(currentCol, currentRow+1);
    }
  else if(pattern === "square"){
    flip(currentCol, currentRow);
    flip(currentCol + 1, currentRow);
    flip(currentCol, currentRow + 1);
    flip(currentCol + 1, currentRow + 1);
  }
  }
}

function flip(col, row){
  // given a column and row for the 2D array, flip its value from 0 to 255 or 255 to 0
  // conditions ensure that the col and row given are valid and exist for the array.
  // If not, no operations take place.
  if (col >= 0 && col < NUM_COLS ){
    if (row >= 0 && row < NUM_ROWS){
      if (gridData[row][col] === 0) gridData[row][col] = 255;
      else gridData[row][col] = 0;
    }
  }
}

function currentSquare(){
  // Determine where the mouse currently is
  currentRow = int(mouseY / rectHeight);
  currentCol = int(mouseX / rectWidth);
}

function drawGrid(){
  // Render a grid of squares - fill color set according to data stored in the 2D array
  for (let x = 0; x < NUM_COLS ; x++){
    for (let y = 0; y < NUM_ROWS; y++){
      fill(gridData[y][x]); 
      rect(x*rectWidth, y*rectHeight, rectWidth, rectHeight);
    }
  }
}

function winner(){
  // Check if all elements are 0 or 255
  // display "You Win"
  let firstValue = gridData[0][0]; //compare all other numbers to this
  let allSame = true;
  for(let x = 0; x < NUM_COLS; x++){
    for(let y = 0; y < NUM_ROWS; y++){
      if(gridData[y][x] !== firstValue){
        allSame = false;
        break;
      }
    }
  }
  if(allSame){ // Completed puzzle
    fill(255, 105, 180);
    textSize(64);
    textAlign(CENTER, CENTER);
    textStyle(BOLD);
    text("You Win!", width / 2, height / 2);  
  }
}

function randomStart(){
  //Display a random pattern each reset
  for(let x = 0; x < NUM_COLS; x++){
    for(let y = 0; y < NUM_ROWS; y++){
      let randomValue = random(255);
      if(randomValue > 127){
        gridData[y][x] = 255;
      }
      else{
        gridData[y][x] = 0;
      }
    }
  }
}

function drawOverlay(){
  //Will show pink highlight of where the tiles would flip
  //Both patterns
  noStroke();
  fill(255, 182, 193, 100);

  if(keyIsDown(SHIFT)){ //Cheater function being used
    drawHighlight(currentCol, currentRow);
  }

  else{
    if(pattern === "cross"){
      drawHighlight(currentCol, currentRow);
      drawHighlight(currentCol-1, currentRow);
      drawHighlight(currentCol+1, currentRow);
      drawHighlight(currentCol, currentRow-1);
      drawHighlight(currentCol, currentRow+1);
    }
    else if(pattern === "square"){
      drawHighlight(currentCol, currentRow);
      drawHighlight(currentCol + 1, currentRow);
      drawHighlight(currentCol, currentRow + 1);
      drawHighlight(currentCol + 1, currentRow + 1);
  }
}
}



function drawHighlight(col, row){
  //draw highlighted rectangle
  //within the boundaries
  if(col >= 0 && col < NUM_COLS &&row >=0 && row < NUM_ROWS){ //In the boundaries
    rect(col * rectWidth, row * rectHeight, rectWidth, rectHeight);
  }
}

function keyPressed(){
  // Spacebar -> changes pattern
  if(keyCode === 32){
    if(pattern === "cross"){
      pattern = "square";
    }
    else{
      pattern = "cross"
    }
  }
}
